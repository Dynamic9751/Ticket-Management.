import React from "react";

const ContactUsPage = () => {
  return <div>ContactUsPage</div>;
};

export default ContactUsPage;
